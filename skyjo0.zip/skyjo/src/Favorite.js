import React from 'react';

function Favorite() {
  return (
    <div>
      <h2>Favorite</h2>
      {/* Ajoutez ici le contenu de la page d'accueil */}
    </div>
  );
}

export default Favorite; 