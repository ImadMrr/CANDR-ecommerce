import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';


function NavigueProd( {name_prod, img_prod, price} ) {
    return (
     
        <h1>Test ok</h1>
    );
  }
  
  export default NavigueProd;
  