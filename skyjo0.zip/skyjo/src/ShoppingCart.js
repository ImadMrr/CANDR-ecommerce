
import React from 'react';

function ShoppingCart() {
  return (
    <div>
      <h2>ShoppingCart</h2>
      {/* Ajoutez ici le contenu de la page d'accueil */}
    </div>
  );
}

export default ShoppingCart;