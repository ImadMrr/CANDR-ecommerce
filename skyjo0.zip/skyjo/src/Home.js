import React from 'react';

function Home() {
  return (
    <div>
      <h2>Home</h2>
      {/* Ajoutez ici le contenu de la page d'accueil */}
    </div>
  );
}

export default Home; // Assurez-vous d'exporter le composant Home
